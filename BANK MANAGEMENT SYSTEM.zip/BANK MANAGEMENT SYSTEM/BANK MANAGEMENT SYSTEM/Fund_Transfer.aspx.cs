﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;

namespace BANK_MANAGEMENT_SYSTEM
{
    public partial class Fund_Transfer : System.Web.UI.Page
    {
        SqlConnection con;
        SqlCommand cmd;
        SqlDataReader dr;

        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void F_sub_Click(object sender, EventArgs e)
        {
            con = new SqlConnection("data source=DESKTOP-GL7RKG7\\SQLEXPRESS; database=banking_system;Trusted_Connection=SSPI;Encrypt=false;TrustServerCertificate=true");
            con.Open();
            int accno=Convert.ToInt32(F_Accno.Value);
            double amt = Convert.ToDouble(F_Amount.Value);
            string act=F_Action.Value;
            double totamt = 10000;
            string stat = "Success";
            cmd = new SqlCommand($"insert into transaction_log(Accountno,action,status,updatedon,Amount,Totalbalance) values" +
                $"({accno},'{act}','{stat}',getdate(),'{amt}',{totamt})", con);
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show($"Amount {amt} is successfully {act}ed");
            Response.Redirect("Bank_Home.aspx");
        }
    }
}